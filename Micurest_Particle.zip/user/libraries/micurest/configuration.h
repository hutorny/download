#pragma message "Default configuration.h used, make your own instead"
