/*
 * wchar.h
 *
 * empty stub for successful compilation with avr gcc
 */
